#include <iostream>
#include "Func.h"
using namespace std;

void Show()
{
	cout << "Show" << endl;
}

void Add()
{
	cout << "Add" << endl;
}

int Sum(int a, int b)
{
	return a+b;
}
