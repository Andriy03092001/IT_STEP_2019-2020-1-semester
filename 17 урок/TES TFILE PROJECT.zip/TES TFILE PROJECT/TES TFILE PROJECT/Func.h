#pragma once

void Show();
void Add();
int Sum(int a, int b);